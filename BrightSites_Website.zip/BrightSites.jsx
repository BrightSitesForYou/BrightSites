import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function BrightSites() {
  return (
    <main className="min-h-screen bg-white text-gray-800 font-sans">
      <header className="bg-blue-600 text-white p-6 shadow-md">
        <h1 className="text-3xl font-bold">Bright Sites</h1>
        <p className="text-md mt-1">Helping Small Businesses Shine Online</p>
      </header>

      <section className="p-6 grid gap-8">
        <div id="home">
          <h2 className="text-2xl font-semibold mb-2">Welcome to Bright Sites!</h2>
          <p>
            We specialize in creating clean, professional websites for small businesses. Let us help you bring your brand online and attract more customers.
          </p>
        </div>

        <div id="services">
          <h2 className="text-2xl font-semibold mb-2">Our Services</h2>
          <ul className="list-disc list-inside">
            <li>Custom-designed websites tailored to your business</li>
            <li>Mobile-friendly and fast-loading pages</li>
            <li>Contact forms, photo galleries, and more</li>
            <li>Ongoing updates and support</li>
          </ul>
        </div>

        <div id="portfolio">
          <h2 className="text-2xl font-semibold mb-2">Portfolio & Examples</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4">
                <img src="https://source.unsplash.com/400x200/?cafe,website" alt="Cafe Example" className="rounded-xl mb-2" />
                <h3 className="font-bold">Local Café</h3>
                <p>A simple, stylish site that showcases their menu and invites online orders.</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <img src="https://source.unsplash.com/400x200/?barbershop,website" alt="Barbershop Example" className="rounded-xl mb-2" />
                <h3 className="font-bold">Neighborhood Barbershop</h3>
                <p>Clean, mobile-first design with appointment booking and reviews.</p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div id="contact">
          <h2 className="text-2xl font-semibold mb-2">Contact Me</h2>
          <p className="mb-4">Reach out via email or fill out the form below, and I’ll get back to you shortly.</p>
          <form className="grid gap-4 max-w-md">
            <input type="text" placeholder="Your Name" className="border p-2 rounded-xl" required />
            <input type="email" placeholder="Your Email" className="border p-2 rounded-xl" required />
            <textarea placeholder="Your Message" className="border p-2 rounded-xl" rows={4} required></textarea>
            <Button type="submit">Send Message</Button>
          </form>
          <p className="mt-4">Or email me directly at <a href="mailto:brightsites@email.com" className="text-blue-600 underline">brightsites@email.com</a></p>
        </div>
      </section>

      <footer className="bg-gray-100 text-center text-sm p-4 mt-8">
        © 2025 Bright Sites. Built to help small businesses grow.
      </footer>
    </main>
  );
}
